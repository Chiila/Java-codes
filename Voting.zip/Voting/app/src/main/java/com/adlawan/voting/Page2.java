package com.adlawan.voting;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
public class Page2 extends AppCompatActivity {
    EditText president;
    EditText Vpresident;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        president = findViewById(R.id.president);
        Vpresident = findViewById(R.id.Vpresident);
    }
    public void goToPage3(View view) {
        name = president.getText().toString();
        Toast.makeText(this, "President, "+name+":", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, Page3.class);
        i.putExtra("name",name);

        name = Vpresident.getText().toString();
        Toast.makeText(this, "Vice President, "+name+":", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, Page3.class);
        i.putExtra("name",name);

        startActivity(i);
        finish();;
    }

    int j = 1;
    public void onBackPressed() {
        if (j == 1){
            j++;
            Toast.makeText(this, "Press the back button again to exit.", Toast.LENGTH_SHORT).show();
        }
    }
}
